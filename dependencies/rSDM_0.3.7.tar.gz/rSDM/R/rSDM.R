#' rSDM: functions for SDM and niche modelling in R
#'
#' rSDM: functions for SDM and niche modelling in R
#'
#' @keywords package
#' @author F. Rodriguez-Sanchez
#' @name rSDM
NULL
